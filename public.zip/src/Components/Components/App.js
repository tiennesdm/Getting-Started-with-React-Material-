import React, { Fragment, useContext } from "react";
// import { AppContext } from "./../Context/Context";
function APPBAR() {
  // const value = useContext(AppContext);
  return <Fragment>Hello World</Fragment>;
}
export default APPBAR;
