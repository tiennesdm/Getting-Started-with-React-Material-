import React, { Fragment } from "react";

export default function ERROR404() {
  return <Fragment>Page Not Found</Fragment>;
}
