import React, { Fragment } from "react";

export default function ERROR500() {
  return <Fragment>Network Error</Fragment>;
}
