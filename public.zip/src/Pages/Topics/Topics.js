import React, { Fragment } from "react";
function Topics() {
  return (
    <Fragment>
      <h2>Topics</h2>
    </Fragment>
  );
}
export default Topics;
