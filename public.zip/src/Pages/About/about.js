import React from "react";
function About() {
  return (
    <React.Fragment>
      <h2>About</h2>
    </React.Fragment>
  );
}
export default About;
